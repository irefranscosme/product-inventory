<?php
require  __DIR__ . "/../vendor/autoload.php";
include_once __DIR__ . "/../src/App.php";

